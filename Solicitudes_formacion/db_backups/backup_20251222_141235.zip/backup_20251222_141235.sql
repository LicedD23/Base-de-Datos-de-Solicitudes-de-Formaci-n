-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: solicitudes_formacion
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `area_formacion_area`
--

DROP TABLE IF EXISTS `area_formacion_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `area_formacion_area` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `fecha_creacion` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_formacion_area`
--

LOCK TABLES `area_formacion_area` WRITE;
/*!40000 ALTER TABLE `area_formacion_area` DISABLE KEYS */;
INSERT INTO `area_formacion_area` VALUES (1,'Maquinaria','Es una formacion en operacion y mantenimiento  de maquinaria pesada, enfocada en  el  desarrrollo de habilidades para operar de forma segura y eficiente equipos como excavadoras, cargadores frontales y retroexcavadoras',1,'2025-10-23 20:12:56.469075'),(2,' Desarrollo de Software','es una formación tecnológica de 27 meses enfocada en la creación de soluciones de software para empresas, desde la elaboración de propuestas técnicas hasta la implementación y el mantenimiento de aplicaciones web y de escritorio',1,'2025-10-27 20:46:10.599805'),(3,'Topografia','se enfoca en formar tecnólogos en Levantamientos Topográficos y Georreferenciación, una carrera que prepara a los aprendices para realizar mediciones precisas del terreno, interpretar planos y desarrollar el modelamiento digital del relieve y otras características del suelo.',1,'2025-10-27 20:47:55.663547'),(4,'Química Aplicada','se enfoca en la formación de tecnólogos y técnicos con habilidades para aplicar conocimientos químicos en procesos industriales. ',1,'2025-10-27 20:51:04.912768');
/*!40000 ALTER TABLE `area_formacion_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add area',7,'add_area'),(26,'Can change area',7,'change_area'),(27,'Can delete area',7,'delete_area'),(28,'Can view area',7,'view_area'),(29,'Can add programa',8,'add_programa'),(30,'Can change programa',8,'change_programa'),(31,'Can delete programa',8,'delete_programa'),(32,'Can view programa',8,'view_programa'),(33,'Can add instructor',9,'add_instructor'),(34,'Can change instructor',9,'change_instructor'),(35,'Can delete instructor',9,'delete_instructor'),(36,'Can view instructor',9,'view_instructor'),(37,'Can add empresa',10,'add_empresa'),(38,'Can change empresa',10,'change_empresa'),(39,'Can delete empresa',10,'delete_empresa'),(40,'Can view empresa',10,'view_empresa'),(41,'Can add solicitud',11,'add_solicitud'),(42,'Can change solicitud',11,'change_solicitud'),(43,'Can delete solicitud',11,'delete_solicitud'),(44,'Can view solicitud',11,'view_solicitud');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$1000000$CeZduHabtPv2EFl0fDgD4e$ddWDjRK+QWRxsshvnq/7RLtTqCvsucYOv0Ltdvjrj2A=','2025-12-19 14:44:43.203593',1,'LicedD','Liced Dayana','Diaz Mayorga','dayadiz.23@gmail.com',1,1,'2025-10-24 01:00:39.613681'),(2,'pbkdf2_sha256$1000000$DtM0ZwlzEcqUXytyGBdYBP$htgs7Q90tp1RDtULAlRLYPSi8I/LiJQzME/eESVOXnA=',NULL,0,'DayanaDM','Dayana','Diaz','dayadi2006@gmail.com',0,1,'2025-11-25 21:56:45.810856'),(4,'pbkdf2_sha256$1000000$cRE2MMk1Uq7rLOtkuDVUbu$/5I6944cP6Aa5k4nFXDHXTlWirt2fQzwwz8XVkiKxBs=',NULL,1,'Martha','Martha Elena','Mayorga Palacios','liceddiaz.08@gmail.com',1,1,'2025-12-10 01:08:11.600846'),(5,'pbkdf2_sha256$1000000$gM78z1XgzTgEUA6yGlQZVd$0e6q/nZCNGQjVOKyXTWevaYa2z+489QQ6g8OTbays/E=',NULL,1,'Hector','','','marthaE@gmail.com',1,1,'2025-12-11 21:31:17.855028');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext COLLATE utf8mb4_unicode_ci,
  `object_repr` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2025-10-23 20:12:56.474522','1','Maquinaria',1,'[{\"added\": {}}, {\"added\": {\"name\": \"programa\", \"object\": \"Maquinaria - operador de excavadora\"}}]',7,1),(2,'2025-10-23 20:24:38.812648','1','ALTARA INGENIERIA SAS',1,'[{\"added\": {}}]',10,1),(3,'2025-10-23 20:30:30.712696','1','Norberto Romero  Gutiérrez',1,'[{\"added\": {}}]',9,1),(4,'2025-10-23 20:32:03.623127','1','ALTARA INGENIERIA SAS - operador de excavadora',1,'[{\"added\": {}}]',11,1),(5,'2025-12-03 16:29:00.080133','14','Análisis y Desarrollo de Software - Análisis y Desarrollo  de Software ',3,'',8,1),(6,'2025-12-03 16:29:00.080203','13','Salud -  primeros auxilios.',3,'',8,1),(7,'2025-12-03 16:29:00.080241','11','Salud - Técnico  en  Enfermería',3,'',8,1),(8,'2025-12-03 16:29:00.080273','12','Salud - Técnico en Atención Integral a la Primera Infancia',3,'',8,1),(9,'2025-12-09 20:09:09.923145','3','Luismi',3,'',4,1),(10,'2025-12-19 12:20:38.104871','16','Agricola - Siembra de plántulas en invernadero',3,'',8,1),(11,'2025-12-19 12:20:38.105312','20','Agricola - fhghgnhjhgnjj',3,'',8,1),(12,'2025-12-19 12:20:38.105450','19','Agricola - hbhjnyjgbvvvf',3,'',8,1),(13,'2025-12-19 12:20:38.105526','18','Agricola - njjuynn',3,'',8,1),(14,'2025-12-19 12:20:38.105676','17','Agricola - yyhhn',3,'',8,1),(15,'2025-12-19 12:47:26.282264','4','Hector Heli Diaz',3,'',9,1),(16,'2025-12-19 12:47:26.282342','3','Héctor Heli Diaz Diaz',3,'',9,1),(17,'2025-12-19 13:44:16.838906','34','MEDIO ORIENTE S.A.S - Operador de Minicargador',3,'',11,1),(18,'2025-12-19 13:44:16.839002','33','CONSTRUCCIONES ORIENTE S.A.S - operador de excavadora',3,'',11,1),(19,'2025-12-19 13:44:16.839051','32','Empresa aperez - Operador de Minicargador',3,'',11,1),(20,'2025-12-19 13:44:16.839093','31','CONSTRUCCIONES EFICACES S.A.S - operador de excavadora',3,'',11,1),(21,'2025-12-19 13:44:16.839130','30','* MAQUINARIAS DEL PACÍFICO S.A.S - Operador de Minicargador',3,'',11,1),(22,'2025-12-19 13:44:16.839160','29','Empresa sin nombre - Operador de Minicargador',3,'',11,1),(23,'2025-12-19 13:44:16.839188','28','*CONSTRUTIERRAS DEL SUR S.A.S* - Operador de Minicargador',3,'',11,1),(24,'2025-12-19 13:44:16.839217','27','*ALMACENES Y DISTRIBUCIONES DEL ORIENTE S.A.S* - Operador de Montacargas',3,'',11,1),(25,'2025-12-19 13:44:16.839257','26','*GEODATOS Y CARTOGRAFÍA URBANA S.A.S* - Georreferenciación',3,'',11,1),(26,'2025-12-19 13:44:16.839293','25','*INGEOBRAS DEL MAGDALENA S.A.S* - operador de excavadora',3,'',11,1),(27,'2025-12-19 13:44:16.839329','24','*LOGÍSTICA INTEGRAL DEL OCCIDENTE S.A.S* - Operador de Montacargas',3,'',11,1),(28,'2025-12-19 13:44:16.839367','23','DATATECH SOLUTIONS S.A.S - Análisis Exploratorio de Datos en Python',3,'',11,1),(29,'2025-12-19 13:44:16.839400','22','INGENIERÍA Y CONSTRUCCIONES DEL CARIBE S.A.S - Operador de Minicargador',3,'',11,1),(30,'2025-12-19 13:44:16.839428','21','*OBRAS Y TERRAMOVIMIENTOS DEL NORTE S.A.S* - Operador de Retrocargador',3,'',11,1),(31,'2025-12-19 13:44:16.839457','20','*MAQUICONSTRUCCIONES DEL CENTRO S.A.S* - Operador de Retrocargador',3,'',11,1),(32,'2025-12-19 13:44:16.839485','19','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Tecnólogo en Procesos de la Industria Química',3,'',11,1),(33,'2025-12-19 13:44:16.839517','18','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Georreferenciación',3,'',11,1),(34,'2025-12-19 13:44:16.839552','17','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Explotación de obras civiles y mineras de acuerdo  con el manual  del  equipo',3,'',11,1),(35,'2025-12-19 13:44:16.839586','16','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Ciberseguridad',3,'',11,1),(36,'2025-12-19 13:44:16.839613','15','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Ciberseguridad',3,'',11,1),(37,'2025-12-19 13:44:16.839643','14','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Ciberseguridad',3,'',11,1),(38,'2025-12-19 13:44:16.839678','13','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Ciberseguridad',3,'',11,1),(39,'2025-12-19 13:44:16.839714','12','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Ciberseguridad',3,'',11,1),(40,'2025-12-19 13:44:16.839744','11','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Operador de Minicargador',3,'',11,1),(41,'2025-12-19 13:44:16.839777','10','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Operador de Montacargas',3,'',11,1),(42,'2025-12-19 13:44:16.839811','9','QUIMIPROCESOS S.A.S - Ciberseguridad',3,'',11,1),(43,'2025-12-19 13:44:16.839841','8','QUIMIPROCESOS S.A.S - Ciberseguridad',3,'',11,1),(44,'2025-12-19 13:44:16.839872','7','QUIMIPROCESOS S.A.S - Ciberseguridad',3,'',11,1),(45,'2025-12-19 13:44:16.839907','6','QUIMIPROCESOS S.A.S - Ciberseguridad',3,'',11,1),(46,'2025-12-19 13:44:16.839944','5','TOPOGRAFÍA Y GEODATOS S.A.S - Ciberseguridad',3,'',11,1),(47,'2025-12-19 13:44:16.839979','4','TECNOLOGÍAS INNOVATEC S.A.S - Ciberseguridad',3,'',11,1),(48,'2025-12-19 13:44:16.840013','3','construcción de obras civiles - operador de excavadora',3,'',11,1),(49,'2025-12-19 13:44:16.840047','2','construcción de obras civiles - operador de excavadora',3,'',11,1),(50,'2025-12-19 13:44:16.840082','1','ALTARA INGENIERIA SAS - operador de excavadora',3,'',11,1),(51,'2025-12-19 13:45:54.630680','23','Empresa maez',3,'',10,1),(52,'2025-12-19 13:45:54.630754','21','Empresa aperez',3,'',10,1),(53,'2025-12-19 13:45:54.630799','17','Empresa sin nombre',3,'',10,1),(54,'2025-12-19 13:45:54.630838','16','*CONSTRUTIERRAS DEL SUR S.A.S*',3,'',10,1),(55,'2025-12-19 13:45:54.630874','15','*ALMACENES Y DISTRIBUCIONES DEL ORIENTE S.A.S*',3,'',10,1),(56,'2025-12-19 13:45:54.630908','14','*GEODATOS Y CARTOGRAFÍA URBANA S.A.S*',3,'',10,1),(57,'2025-12-19 13:45:54.630942','13','*INGEOBRAS DEL MAGDALENA S.A.S*',3,'',10,1),(58,'2025-12-19 13:45:54.630976','12','*LOGÍSTICA INTEGRAL DEL OCCIDENTE S.A.S*',3,'',10,1),(59,'2025-12-19 13:45:54.631009','11','DATATECH SOLUTIONS S.A.S',3,'',10,1),(60,'2025-12-19 13:45:54.631043','10','INGENIERÍA Y CONSTRUCCIONES DEL CARIBE S.A.S',3,'',10,1),(61,'2025-12-19 13:45:54.631076','9','*OBRAS Y TERRAMOVIMIENTOS DEL NORTE S.A.S*',3,'',10,1),(62,'2025-12-19 13:45:54.631110','8','*MAQUICONSTRUCCIONES DEL CENTRO S.A.S*',3,'',10,1),(63,'2025-12-19 13:45:54.631143','7','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S',3,'',10,1),(64,'2025-12-22 18:10:41.962068','7','Miguel Diaz',3,'',9,1),(65,'2025-12-22 18:10:41.962154','6','Carlos Mateus Gonzales gomez ',3,'',9,1),(66,'2025-12-22 18:10:41.962198','5','Martha Elena Mayorga',3,'',9,1),(67,'2025-12-22 18:12:17.286139','6','Administración',3,'',7,1),(68,'2025-12-22 18:12:17.286229','7','Agricola',3,'',7,1),(69,'2025-12-22 18:12:17.286276','9','Amasijos',3,'',7,1),(70,'2025-12-22 18:12:17.286315','10','Contrucciones',3,'',7,1),(71,'2025-12-22 18:12:17.286350','8','Ganadera',3,'',7,1),(72,'2025-12-22 18:12:17.286387','5','Salud',3,'',7,1),(73,'2025-12-22 18:12:43.972016','32','mnmnjkmnhgbv',3,'',10,1),(74,'2025-12-22 18:12:43.972100','18','Empresa sin nombre',3,'',10,1),(75,'2025-12-22 18:12:43.972146','3','construcción de obras civiles',3,'',10,1),(76,'2025-12-22 18:15:43.898727','15',' Desarrollo de Software - Análisis de datos',3,'',8,1),(77,'2025-12-22 18:15:43.898813','10',' Desarrollo de Software - Análisis Exploratorio de Datos en Python',3,'',8,1),(78,'2025-12-22 18:15:43.898858','2',' Desarrollo de Software - Ciberseguridad',3,'',8,1),(79,'2025-12-22 18:15:43.898896','4','Química Aplicada - Tecnólogo en Procesos de la Industria Química',3,'',8,1),(80,'2025-12-22 18:23:54.075002','2','Marcos Ferney Suarez Martinez',3,'',9,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(7,'area_formacion','area'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(10,'empresas','empresa'),(9,'instructores','instructor'),(8,'programas','programa'),(6,'sessions','session'),(11,'solicitudes','solicitud');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2025-12-19 14:14:45.574366'),(2,'auth','0001_initial','2025-12-19 14:14:46.468931'),(3,'admin','0001_initial','2025-12-19 14:14:46.704886'),(4,'admin','0002_logentry_remove_auto_add','2025-12-19 14:14:46.718415'),(5,'admin','0003_logentry_add_action_flag_choices','2025-12-19 14:14:46.736211'),(6,'area_formacion','0001_initial','2025-12-19 14:14:46.789097'),(7,'contenttypes','0002_remove_content_type_name','2025-12-19 14:14:46.974746'),(8,'auth','0002_alter_permission_name_max_length','2025-12-19 14:14:47.085854'),(9,'auth','0003_alter_user_email_max_length','2025-12-19 14:14:47.146137'),(10,'auth','0004_alter_user_username_opts','2025-12-19 14:14:47.163660'),(11,'auth','0005_alter_user_last_login_null','2025-12-19 14:14:47.267030'),(12,'auth','0006_require_contenttypes_0002','2025-12-19 14:14:47.271184'),(13,'auth','0007_alter_validators_add_error_messages','2025-12-19 14:14:47.288778'),(14,'auth','0008_alter_user_username_max_length','2025-12-19 14:14:47.406630'),(15,'auth','0009_alter_user_last_name_max_length','2025-12-19 14:14:47.532771'),(16,'auth','0010_alter_group_name_max_length','2025-12-19 14:14:47.573296'),(17,'auth','0011_update_proxy_permissions','2025-12-19 14:14:47.597149'),(18,'auth','0012_alter_user_first_name_max_length','2025-12-19 14:14:47.710663'),(19,'empresas','0001_initial','2025-12-19 14:14:47.754531'),(20,'empresas','0002_empresa_direccion','2025-12-19 14:14:47.843435'),(21,'empresas','0003_empresa_activo','2025-12-19 14:14:47.935232'),(22,'empresas','0004_empresa_nit','2025-12-19 14:14:48.006698'),(23,'programas','0001_initial','2025-12-19 14:14:48.154757'),(24,'instructores','0001_initial','2025-12-19 14:14:48.405636'),(25,'programas','0002_programa_codigo','2025-12-19 14:14:48.510892'),(26,'sessions','0001_initial','2025-12-19 14:14:48.576076'),(27,'solicitudes','0001_initial','2025-12-19 14:14:48.892647'),(28,'solicitudes','0002_solicitud_fecha_finalizacion_and_more','2025-12-19 14:14:49.050624');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('13ffq7t2gyn3afdq1wesgrv079vwlzqs','.eJxVjEEOwiAQRe_C2hAoUIpL956BzDCDVA0kpV0Z765NutDtf-_9l4iwrSVunZc4kzgLLU6_G0J6cN0B3aHemkytrsuMclfkQbu8NuLn5XD_Dgr08q0zOAwQTM4pgQNi7zENLo1qYoWWOJCzmtCzydp47ycE4Iw4Kh0Ga8T7AybbOSE:1vHNto:dsCXMWAftW9tWhNQV4wF-KbAhVpiaDfKpSCeSEyco5Q','2025-11-21 14:57:12.395575'),('eqmrevjp2sieoodz8y0mc9hazd0pc70d','.eJxVjEEOwiAQRe_C2hAoUIpL956BzDCDVA0kpV0Z765NutDtf-_9l4iwrSVunZc4kzgLLU6_G0J6cN0B3aHemkytrsuMclfkQbu8NuLn5XD_Dgr08q0zOAwQTM4pgQNi7zENLo1qYoWWOJCzmtCzydp47ycE4Iw4Kh0Ga8T7AybbOSE:1vWa7e:VwvnWNxRUBKDGwWEzk_g3GDq7fUikl-LrQk4b04PMOM','2026-01-02 13:02:18.785030'),('h2m8lzi8cgqb5yeg0hpynpul3m3utm9c','.eJxVjEEOwiAQRe_C2hAoUIpL956BzDCDVA0kpV0Z765NutDtf-_9l4iwrSVunZc4kzgLLU6_G0J6cN0B3aHemkytrsuMclfkQbu8NuLn5XD_Dgr08q0zOAwQTM4pgQNi7zENLo1qYoWWOJCzmtCzydp47ycE4Iw4Kh0Ga8T7AybbOSE:1vQphE:yRu7RQvr6YasZck1jUYhVJgCNWCiNWLayA3rAQnQkI4','2025-12-17 16:27:16.737161'),('onk70coa16qoarlyhcbuhqlt3jifwk0y','.eJxVjEEOwiAQRe_C2hAoUIpL956BzDCDVA0kpV0Z765NutDtf-_9l4iwrSVunZc4kzgLLU6_G0J6cN0B3aHemkytrsuMclfkQbu8NuLn5XD_Dgr08q0zOAwQTM4pgQNi7zENLo1qYoWWOJCzmtCzydp47ycE4Iw4Kh0Ga8T7AybbOSE:1vSzEO:7nT-7NNfnZBj5faQed0LjsVjhavS2EQPBXJN5LIDK8E','2025-12-23 15:02:24.765287'),('onsz7oeuukh5kzuywrl0apywmd1ubyv3','.eJxVjEEOwiAQRe_C2hAoUIpL956BzDCDVA0kpV0Z765NutDtf-_9l4iwrSVunZc4kzgLLU6_G0J6cN0B3aHemkytrsuMclfkQbu8NuLn5XD_Dgr08q0zOAwQTM4pgQNi7zENLo1qYoWWOJCzmtCzydp47ycE4Iw4Kh0Ga8T7AybbOSE:1vCGXL:FMeQQyoTX6EUlORzsShMmtM7Gkmm9c4stCTsVuGjkE4','2025-11-07 12:04:51.328488'),('yqr7k8hcypuzc44y5mtlnppqsg3jye1y','.eJxVjEEOwiAQRe_C2hAoUIpL956BzDCDVA0kpV0Z765NutDtf-_9l4iwrSVunZc4kzgLLU6_G0J6cN0B3aHemkytrsuMclfkQbu8NuLn5XD_Dgr08q0zOAwQTM4pgQNi7zENLo1qYoWWOJCzmtCzydp47ycE4Iw4Kh0Ga8T7AybbOSE:1vWbil:uOYlLTmDx2DXODeRGHWCbJew42dp_JOqlZXygSCdO6M','2026-01-02 14:44:43.230064');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresas_empresa`
--

DROP TABLE IF EXISTS `empresas_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empresas_empresa` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contacto` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correo` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_trabajadores` int NOT NULL,
  `municipio` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_registro` datetime(6) NOT NULL,
  `direccion` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `nit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresas_empresa`
--

LOCK TABLES `empresas_empresa` WRITE;
/*!40000 ALTER TABLE `empresas_empresa` DISABLE KEYS */;
INSERT INTO `empresas_empresa` VALUES (1,'ALTARA INGENIERIA SAS','Laura Gómez','3104567890','contacto@altarasolutions.com',45,'Medellín','2025-10-23 20:24:38.809577','',1,NULL),(2,'Constructora FYT S.A.S','Martha Mayorga','3114532122','constructora@fyt.com',25,'Sogamoso','2025-11-05 12:46:47.926557','',1,NULL),(4,'TECNOLOGÍAS INNOVATEC S.A.S','Sin contacto especificado','320-456-7890','laura.martinez@innovatec.com',0,'No especificado','2025-11-12 13:01:44.166214','',1,NULL),(5,'TOPOGRAFÍA Y GEODATOS S.A.S','Sin contacto especificado','Sin teléfono','carlos.ramirez@geodatos.com',0,'No especificado','2025-11-12 13:15:07.505818','',1,NULL),(6,'QUIMIPROCESOS S.A.S','Sin contacto especificado','Sin teléfono','maria.gomez@quimiprocesos.com',0,'No especificado','2025-11-12 13:37:10.228477','',1,NULL),(19,'* MAQUINARIAS DEL PACÍFICO S.A.S','* Laura Marcela Torres','2315678564','ltorres@maquinariasdelpacifico.co',33,'Palmira','2025-11-14 18:47:58.867933','',1,'9002769621'),(20,'CONSTRUCCIONES EFICACES S.A.S','Juan Carlos Martínez','3104567890','jmartinez@construccioneseficaces.co',45,'Cali','2025-11-18 13:41:55.774520','Calle 15 # 34-56, Barrio El Trapiche',1,NULL),(22,'CONSTRUCCIONES ORIENTE S.A.S','Liced Maria Diaz','3194563490','maez@construccionoriente.co',45,'Sogamoso','2025-11-18 13:57:24.829688','Calle 16 # 34-56',1,NULL),(24,'MEDIO ORIENTE S.A.S','Tatiana Dayan Oviedo','3142460488','dayadiz.23@gmail.com',35,'Sogamoso','2025-11-19 18:45:05.666683','Calle 19 # 34-56',1,NULL),(25,'CONSTRUOBRAS & EQUIPOS S.A.S','Andrés Felipe Molina','3217079852','af.molina@construobrasyequipos.com',38,'Medellín','2025-11-27 16:01:38.894094','Carrera 54 # 32-118, Parque Industrial Guayabal',1,NULL),(26,'SERVIMAQ INDUSTRIAL S.A.S','Diego Alejandro Robles','3124459068','d.robles@servimaqindustrial.com',42,'','2025-11-27 16:13:24.627393','Avenida Quebradaseca # 23-41, Parque Empresarial La Ceiba',1,NULL),(27,'LOGISTIWARE COLOMBIA S.A.S','María Fernanda Cárdenas','3145628974','mf.cardenas@logistiware.com',72,'Cali','2025-11-27 18:28:34.640643','Calle 44 # 18-52, Zona Industrial Acopi Yumbo',1,'9004805691'),(28,'Minería S.A.S','Yalith Jimenez','3124567345','yadi.3456@gmail.com',14,'Palmira','2025-12-04 19:33:24.472015','',1,NULL),(29,'Topógrafos unidos S.A.S','Wilson Aguilar Jiménez','3234675431','wilson34@sena.edu.com',34,'Duitama','2025-12-05 12:11:18.606401','carrera 9 #34-89',1,'8909035112'),(30,'Contruboy S.A.S','Marcelo Antonio Palacios','31245678756','quityuli@gmail.com',56,'Palermo','2025-12-05 12:24:36.639923','calle 4 #25-78 vereda el  fical',1,'9002745621'),(31,'Contrucciones el Condor S.A','Mariana Campos','3236574321','MarianaCA@sena.edu.co',30,'Medellín','2025-12-05 13:13:57.474185','Carrera 25 3 45 PISO 3, Medellín, Antioquia',0,'8909224474'),(33,'GEODATA SOLUTIONS S.A.S','Andrés Camacho','3137854420','andres.camacho@geodatasolutions.com',0,'Medellín','2025-12-10 12:17:04.261199','Calle 48 # 65-12, Oficina 304',1,'902345678'),(34,'MAQUINARIAS DEL PACÍFICO S.A.S','Carolina Ríos','','carolina.rios@maquinariaspacifico.com',0,'Buenaventura','2025-12-10 12:24:46.098380','Carrera 5 # 21-44, Bodega 7',1,'901678234'),(35,'CONSTRUCCIONES Y MOVIMIENTOS DEL NORTE S.A.S','Laura Marcela Pineda','3116824507','laura.pineda@movimientosnorte.com',0,'Montería','2025-12-15 19:20:36.513567','Avenida Circunvalar # 34-92, Oficina 204',1,'900734589'),(36,'LOGÍSTICA INDUSTRIAL ANDINA S.A.S','Andrés Felipe Muñoz','3204579931','andres.munoz@logisticaandina.com',0,'Yumbo','2025-12-15 19:20:36.512720','Calle 12 # 18-60, Parque Industrial Zona Norte',1,'901845672'),(37,'LOGÍSTICA Y SERVICIOS INDUSTRIALES DEL CARIBE S.A.S','Carlos Andrés Mejía','3004587921','carlos.mejia@logisticacaribe.com',0,'Barranquilla','2025-12-19 12:38:37.135590','Calle 72 # 45-18, Bodega 6',1,'901245678'),(38,'SERVICIOS LOGÍSTICOS Y TRANSPORTE INDUSTRIAL S.A.S','Juan Sebastián Ríos','3147769032','juan.rios@servilogisticaindustrial.com',0,'Medellín','2025-12-19 13:06:50.951839','Calle 30 # 65-120, Bodega 12',1,'900987654');
/*!40000 ALTER TABLE `empresas_empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructores_instructor`
--

DROP TABLE IF EXISTS `instructores_instructor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructores_instructor` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correo` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructores_instructor`
--

LOCK TABLES `instructores_instructor` WRITE;
/*!40000 ALTER TABLE `instructores_instructor` DISABLE KEYS */;
INSERT INTO `instructores_instructor` VALUES (1,'Norberto Romero  Gutiérrez Perez','3142460488','norberto@sena.edu.com',1),(8,'Ederson Infante ','325678956','enderson.infante@sena.edu.co',0);
/*!40000 ALTER TABLE `instructores_instructor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructores_instructor_especialidad`
--

DROP TABLE IF EXISTS `instructores_instructor_especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructores_instructor_especialidad` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `instructor_id` bigint NOT NULL,
  `programa_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `instructores_instructor__instructor_id_programa_i_80dc0c9e_uniq` (`instructor_id`,`programa_id`),
  KEY `instructores_instruc_programa_id_b9b8492b_fk_programas` (`programa_id`),
  CONSTRAINT `instructores_instruc_instructor_id_ba03593f_fk_instructo` FOREIGN KEY (`instructor_id`) REFERENCES `instructores_instructor` (`id`),
  CONSTRAINT `instructores_instruc_programa_id_b9b8492b_fk_programas` FOREIGN KEY (`programa_id`) REFERENCES `programas_programa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructores_instructor_especialidad`
--

LOCK TABLES `instructores_instructor_especialidad` WRITE;
/*!40000 ALTER TABLE `instructores_instructor_especialidad` DISABLE KEYS */;
INSERT INTO `instructores_instructor_especialidad` VALUES (1,1,1),(2,1,8),(14,8,1);
/*!40000 ALTER TABLE `instructores_instructor_especialidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programas_programa`
--

DROP TABLE IF EXISTS `programas_programa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `programas_programa` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `duracion_horas` int DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `fecha_creacion` datetime(6) NOT NULL,
  `area_id` bigint NOT NULL,
  `codigo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `programas_programa_area_id_nombre_8bf86235_uniq` (`area_id`,`nombre`),
  CONSTRAINT `programas_programa_area_id_6d7cdeb9_fk_area_formacion_area_id` FOREIGN KEY (`area_id`) REFERENCES `area_formacion_area` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programas_programa`
--

LOCK TABLES `programas_programa` WRITE;
/*!40000 ALTER TABLE `programas_programa` DISABLE KEYS */;
INSERT INTO `programas_programa` VALUES (1,'operador de excavadora','Un operador de excavadora en el SENA es una persona que se forma para operar maquinaria pesada de manera segura y eficiente, realizando tareas como la excavación, carga, nivelación y transporte de materiales en proyectos de construcción, minería y obras civiles.',140,1,'2025-10-23 20:12:56.472977',1,''),(3,'Georreferenciación','La georreferenciación en la topografía del SENA es la técnica para asignar coordenadas geográficas (latitud, longitud, altura) a puntos, características o planos de un terreno, con el fin de ubicar elementos de forma precisa en la superficie terrestre.',48,1,'2025-11-12 13:11:45.564906',3,''),(5,'Operador de Retrocargador',' Un operador de retrocargador es un profesional capacitado para manejar maquinaria pesada como la retroexcavadora, realizando tareas de excavación, carga y nivelación de terrenos para construcción.',40,1,'2025-11-12 18:45:04.277187',1,''),(6,'Explotación de obras civiles y mineras de acuerdo  con el manual  del  equipo','La explotación de obras civiles y mineras, según el manual del equipo del Sena, se refiere al uso adecuado de maquinaria y procedimientos para excavar, extraer y procesar recursos minerales y construir infraestructura. Esto se rige por la aplicación de técnicas de perforación, voladura, sostenimiento y seguridad, además del uso de software especializado, como parte integral de los programas de formación del SENA. ',40,1,'2025-11-12 18:48:15.855806',1,''),(7,'Operador de Minicargador','Es un profesional que ha recibido formación técnica para manejar de forma segura y eficiente estos equipos compactos, que se utilizan para cargar, descargar, nivelar y desplazar materiales en diversas industrias como la construcción, la minería y la agricultura.',40,1,'2025-11-12 18:51:09.568284',1,''),(8,'Operador de Montacargas','Un operador de montacargas es una persona que ha recibido capacitación para manipular estos equipos de manera segura y eficiente en almacenes, fábricas y otros entornos logísticos. La formación cubre desde la operación básica hasta el mantenimiento preventivo y la normativa de seguridad, permitiendo el traslado de mercancías y la optimización de procesos. ',50,1,'2025-11-12 18:53:10.033247',1,'2345687'),(9,'Sistemas Hidráulicos en  Maquinaria Pesada','Los Sistemas Hidráulicos en Maquinaria Pesada se refieren a un programa de formación que enseña a los aprendices cómo funcionan, se operan y se mantienen los sistemas que usan fluidos a presión para realizar trabajos pesados. La formación se centra en los componentes clave como bombas, cilindros y válvulas, y su aplicación práctica en equipos como excavadoras, grúas y volquetes. ',40,1,'2025-11-12 18:55:55.581401',1,''),(16,'Interpretación de planos para maquinaria industrial ','El programa Interpretación de Planos para Maquinaria Industrial trata de enseñar a leer y entender los documentos técnicos gráficos (planos) que representan componentes y ensamblajes de maquinaria, desarrollando habilidades para comprender vistas, simbología, acotaciones y especificaciones técnicas, fundamental para el mantenimiento, fabricación y operación de máquinas en el sector industrial. ',40,1,'2025-12-22 19:02:37.274345',1,'6789564');
/*!40000 ALTER TABLE `programas_programa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitudes_solicitud`
--

DROP TABLE IF EXISTS `solicitudes_solicitud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solicitudes_solicitud` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha_recepcion` datetime(6) NOT NULL,
  `fecha_respuesta` datetime(6) DEFAULT NULL,
  `fecha_atencion` datetime(6) DEFAULT NULL,
  `estado` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observaciones` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `empresa_id` bigint NOT NULL,
  `instructor_asignado_id` bigint DEFAULT NULL,
  `programa_id` bigint NOT NULL,
  `fecha_finalizacion` datetime(6) DEFAULT NULL,
  `numero_aprendices` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `solicitudes_solicitud_empresa_id_8f63b86a_fk_empresas_empresa_id` (`empresa_id`),
  KEY `solicitudes_solicitu_instructor_asignado__67d25fd3_fk_instructo` (`instructor_asignado_id`),
  KEY `solicitudes_solicitu_programa_id_54afc508_fk_programas` (`programa_id`),
  CONSTRAINT `solicitudes_solicitu_instructor_asignado__67d25fd3_fk_instructo` FOREIGN KEY (`instructor_asignado_id`) REFERENCES `instructores_instructor` (`id`),
  CONSTRAINT `solicitudes_solicitu_programa_id_54afc508_fk_programas` FOREIGN KEY (`programa_id`) REFERENCES `programas_programa` (`id`),
  CONSTRAINT `solicitudes_solicitud_empresa_id_8f63b86a_fk_empresas_empresa_id` FOREIGN KEY (`empresa_id`) REFERENCES `empresas_empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitudes_solicitud`
--

LOCK TABLES `solicitudes_solicitud` WRITE;
/*!40000 ALTER TABLE `solicitudes_solicitud` DISABLE KEYS */;
INSERT INTO `solicitudes_solicitud` VALUES (35,'2025-11-27 16:01:38.930209',NULL,NULL,'RECIBIDA','',25,NULL,7,NULL,NULL),(36,'2025-11-27 16:13:24.697517',NULL,NULL,'RECIBIDA','',26,NULL,7,NULL,NULL),(37,'2025-11-27 18:28:34.680694',NULL,NULL,'RECIBIDA','',27,NULL,8,NULL,NULL),(38,'2025-12-10 12:24:46.123189',NULL,NULL,'RECIBIDA','',34,NULL,7,NULL,NULL),(39,'2025-12-15 19:20:36.562503','2025-12-17 15:46:31.103102','2025-12-17 19:32:46.545219','FINALIZADA','Creada automáticamente desde correo: Solicitud programa operador de montacargas',36,NULL,8,'2025-12-17 19:40:49.916859',NULL),(40,'2025-12-15 19:20:36.545908','2025-12-17 18:23:36.781201','2025-12-17 19:57:25.634834','FINALIZADA','Creada automáticamente desde correo: Solicitud programa operador de minicargador',35,NULL,7,'2025-12-17 19:59:44.813605',NULL),(41,'2025-12-19 12:38:37.168447',NULL,NULL,'RECIBIDA','Creada automáticamente desde correo: Solicitud programa operador de montacargas',37,NULL,8,NULL,NULL),(42,'2025-12-19 13:06:50.990993',NULL,NULL,'RECIBIDA','Creada automáticamente desde correo: Solicitud programa de formación operador de montac',38,NULL,8,NULL,NULL);
/*!40000 ALTER TABLE `solicitudes_solicitud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'solicitudes_formacion'
--

--
-- Dumping routines for database 'solicitudes_formacion'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-22 14:12:35
