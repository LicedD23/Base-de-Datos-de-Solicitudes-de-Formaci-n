-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: solicitudes_formacion
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `area_formacion_area`
--

DROP TABLE IF EXISTS `area_formacion_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `area_formacion_area` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `fecha_creacion` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_formacion_area`
--

LOCK TABLES `area_formacion_area` WRITE;
/*!40000 ALTER TABLE `area_formacion_area` DISABLE KEYS */;
INSERT INTO `area_formacion_area` VALUES (1,'Maquinaria','Es una formacion en operacion y mantenimiento  de maquinaria pesada, enfocada en  el  desarrrollo de habilidades para operar de forma segura y eficiente equipos como excavadoras, cargadores frontales y retroexcavadoras',1,'2025-10-23 20:12:56.469075'),(3,'Topografia','se enfoca en formar tecnólogos en Levantamientos Topográficos y Georreferenciación, una carrera que prepara a los aprendices para realizar mediciones precisas del terreno, interpretar planos y desarrollar el modelamiento digital del relieve y otras características del suelo.',1,'2025-10-27 20:47:55.663547'),(12,'Minas','El área de minas del SENA, centrada en su Centro Minero en Sogamoso, Boyacá, es un referente latinoamericano que forma profesionales en minería formal, segura y tecnológica, utilizando una mina didáctica única con apoyo internacional para simular operaciones reales, abarcando desde la perforación y voladura hasta la supervisión y seguridad, buscando la innovación y sostenibilidad del sector. ',1,'2026-01-08 16:03:53.836769'),(13,'Alturas','El área de Alturas del SENA se enfoca en la formación para el Trabajo Seguro en Alturas, ofreciendo programas certificados (Básico, Avanzado, Coordinador, Reentrenamiento, Entrenador) que desarrollan competencias técnicas y sociales para prevenir caídas y accidentes, cumpliendo la normativa colombiana (Resolución 4272/2021), mediante entrenamiento en ambientes especializados, preparando al personal para diversos sectores como construcción, energía e industria',0,'2026-01-08 16:04:55.735870'),(14,'Joyeria','El área de joyería del SENA forma artesanos y técnicos capaces de diseñar, fabricar, ajustar y reparar piezas en metales preciosos (oro, plata) y piedras, combinando técnicas tradicionales (armado, engaste, fundición) con tecnología (diseño 3D), desarrollando competencias para responder a mercados globales, desde la creación de prototipos hasta la producción en serie, asegurando calidad y acabado profesional. ',1,'2026-01-08 16:06:16.785922'),(15,'Fontaneria','El área de fontanería del SENA capacita y certifica a personas en la instalación, mantenimiento y reparación de redes de acueductos, alcantarillados y sistemas hidráulicos en edificaciones, desde lo básico hasta lo municipal, incluyendo manejo de agua potable, saneamiento, aparatos sanitarios y, a veces, gas, con el objetivo de garantizar la calidad del servicio y la infraestructura hídrica del país. ',1,'2026-01-08 16:09:07.658426'),(16,'Salud y Seguridad en  el  Trabajo','El área de Seguridad y Salud en el Trabajo (SST) del SENA es un sistema integral que busca prevenir accidentes y enfermedades laborales, promoviendo una cultura de autocuidado y ambientes de trabajo sanos mediante la identificación, evaluación y control de peligros, cumpliendo la normativa legal y fomentando la participación de todos, desde aprendices hasta directivos, para proteger la salud física, mental y social en todos los entornos laborales. ',1,'2026-01-08 16:10:43.723435'),(17,'Ambiental','El área ambiental en el trabajo del SENA se enfoca en la ** Gestión Ambiental (SGA)**, implementando políticas y procedimientos (como la norma ISO 14001) para identificar y controlar los impactos ambientales de sus actividades, promoviendo la prevención de la contaminación, el uso eficiente de recursos (agua, energía), y la gestión de residuos, buscando la sostenibilidad y el cumplimiento legal, formando además profesionales en esta área para el sector productivo. ',1,'2026-01-08 16:12:38.638085'),(18,'CANPESENA','Es la oportunidad para que las campesinas y los campesinos accedan con mayor facilidad a los programas de formación especial y servicios del SENA, según sus necesidades. CampeSENA reivindica el campo colombiano en busca de la justicia social.',1,'2026-01-08 16:14:41.467879'),(19,'Construcción','El Área de Construcción del SENA ofrece formación integral (técnica, tecnológica y especialización) en el sector, capacitando talento humano para la construcción de edificaciones, desde cimientos y estructuras hasta acabados e instalaciones, mediante ambientes modernos, laboratorios (suelos, hidráulica, topografía) y competencias prácticas en mampostería, concreto, presupuestos, y supervisión de obra, buscando la vanguardia tecnológica y la empleabilidad. ',1,'2026-01-08 16:16:25.847929'),(20,'Economía Popular','El área de Economía Popular del SENA se enfoca en apoyar a trabajadores autónomos, emprendedores y microempresarios (dueños de micronegocios o unidades productivas personales/familiares/comunitarias) mediante formación, capacitación, asesoría, acceso a capital (Fondo Emprender), certificación de competencias laborales y fortalecimiento de la asociatividad para mejorar sus ingresos, productividad, y facilitar su acceso a nuevos mercados, digitalización y formalización, dignificando sus oficios y cerrando brechas de desigualdad. ',1,'2026-01-08 16:19:03.361876'),(21,'Riesgo Eléctrico','El área de Riesgo Eléctrico del SENA se enfoca en capacitar sobre los peligros y prevención de accidentes por electricidad, cubriendo desde choques eléctricos, quemaduras, arcos eléctricos hasta caídas, mediante el estudio de la normativa (como el RETIE), efectos fisiológicos, uso de EPP, procedimientos seguros y primeros auxilios, para formar técnicos capaces de gestionar la energía eléctrica de forma segura en entornos residenciales e industriales, según sus fichas técnicas y repositorios. ',1,'2026-01-08 16:20:50.312095');
/*!40000 ALTER TABLE `area_formacion_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add area',7,'add_area'),(26,'Can change area',7,'change_area'),(27,'Can delete area',7,'delete_area'),(28,'Can view area',7,'view_area'),(29,'Can add programa',8,'add_programa'),(30,'Can change programa',8,'change_programa'),(31,'Can delete programa',8,'delete_programa'),(32,'Can view programa',8,'view_programa'),(33,'Can add instructor',9,'add_instructor'),(34,'Can change instructor',9,'change_instructor'),(35,'Can delete instructor',9,'delete_instructor'),(36,'Can view instructor',9,'view_instructor'),(37,'Can add empresa',10,'add_empresa'),(38,'Can change empresa',10,'change_empresa'),(39,'Can delete empresa',10,'delete_empresa'),(40,'Can view empresa',10,'view_empresa'),(41,'Can add solicitud',11,'add_solicitud'),(42,'Can change solicitud',11,'change_solicitud'),(43,'Can delete solicitud',11,'delete_solicitud'),(44,'Can view solicitud',11,'view_solicitud'),(45,'Can add Documento de Solicitud',12,'add_documentosolicitud'),(46,'Can change Documento de Solicitud',12,'change_documentosolicitud'),(47,'Can delete Documento de Solicitud',12,'delete_documentosolicitud'),(48,'Can view Documento de Solicitud',12,'view_documentosolicitud');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$1000000$CeZduHabtPv2EFl0fDgD4e$ddWDjRK+QWRxsshvnq/7RLtTqCvsucYOv0Ltdvjrj2A=','2026-01-30 13:09:41.248574',1,'LicedD','Liced Dayana','Diaz Mayorga','dayadiz.23@gmail.com',1,1,'2025-10-24 01:00:39.613681'),(2,'pbkdf2_sha256$1000000$DtM0ZwlzEcqUXytyGBdYBP$htgs7Q90tp1RDtULAlRLYPSi8I/LiJQzME/eESVOXnA=',NULL,0,'DayanaDM','Dayana','Diaz','dayadi2006@gmail.com',0,1,'2025-11-25 21:56:45.810856'),(4,'pbkdf2_sha256$1000000$w7A02t84s2ZfJjsoILIFdD$Tyk/N3M07y7NBky5RbD1rdLemsD4NwqeBkO/O3LP/pk=','2025-12-29 13:47:50.840127',1,'Martha','Martha Elena','Mayorga Palacios','liceddiaz.08@gmail.com',1,1,'2025-12-10 01:08:11.600846'),(5,'pbkdf2_sha256$1000000$gM78z1XgzTgEUA6yGlQZVd$0e6q/nZCNGQjVOKyXTWevaYa2z+489QQ6g8OTbays/E=',NULL,1,'Hector','','','marthaE@gmail.com',1,1,'2025-12-11 21:31:17.855028');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext COLLATE utf8mb4_unicode_ci,
  `object_repr` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2025-10-23 20:12:56.474522','1','Maquinaria',1,'[{\"added\": {}}, {\"added\": {\"name\": \"programa\", \"object\": \"Maquinaria - operador de excavadora\"}}]',7,1),(2,'2025-10-23 20:24:38.812648','1','ALTARA INGENIERIA SAS',1,'[{\"added\": {}}]',10,1),(3,'2025-10-23 20:30:30.712696','1','Norberto Romero  Gutiérrez',1,'[{\"added\": {}}]',9,1),(4,'2025-10-23 20:32:03.623127','1','ALTARA INGENIERIA SAS - operador de excavadora',1,'[{\"added\": {}}]',11,1),(5,'2025-12-03 16:29:00.080133','14','Análisis y Desarrollo de Software - Análisis y Desarrollo  de Software ',3,'',8,1),(6,'2025-12-03 16:29:00.080203','13','Salud -  primeros auxilios.',3,'',8,1),(7,'2025-12-03 16:29:00.080241','11','Salud - Técnico  en  Enfermería',3,'',8,1),(8,'2025-12-03 16:29:00.080273','12','Salud - Técnico en Atención Integral a la Primera Infancia',3,'',8,1),(9,'2025-12-09 20:09:09.923145','3','Luismi',3,'',4,1),(10,'2025-12-19 12:20:38.104871','16','Agricola - Siembra de plántulas en invernadero',3,'',8,1),(11,'2025-12-19 12:20:38.105312','20','Agricola - fhghgnhjhgnjj',3,'',8,1),(12,'2025-12-19 12:20:38.105450','19','Agricola - hbhjnyjgbvvvf',3,'',8,1),(13,'2025-12-19 12:20:38.105526','18','Agricola - njjuynn',3,'',8,1),(14,'2025-12-19 12:20:38.105676','17','Agricola - yyhhn',3,'',8,1),(15,'2025-12-19 12:47:26.282264','4','Hector Heli Diaz',3,'',9,1),(16,'2025-12-19 12:47:26.282342','3','Héctor Heli Diaz Diaz',3,'',9,1),(17,'2025-12-19 13:44:16.838906','34','MEDIO ORIENTE S.A.S - Operador de Minicargador',3,'',11,1),(18,'2025-12-19 13:44:16.839002','33','CONSTRUCCIONES ORIENTE S.A.S - operador de excavadora',3,'',11,1),(19,'2025-12-19 13:44:16.839051','32','Empresa aperez - Operador de Minicargador',3,'',11,1),(20,'2025-12-19 13:44:16.839093','31','CONSTRUCCIONES EFICACES S.A.S - operador de excavadora',3,'',11,1),(21,'2025-12-19 13:44:16.839130','30','* MAQUINARIAS DEL PACÍFICO S.A.S - Operador de Minicargador',3,'',11,1),(22,'2025-12-19 13:44:16.839160','29','Empresa sin nombre - Operador de Minicargador',3,'',11,1),(23,'2025-12-19 13:44:16.839188','28','*CONSTRUTIERRAS DEL SUR S.A.S* - Operador de Minicargador',3,'',11,1),(24,'2025-12-19 13:44:16.839217','27','*ALMACENES Y DISTRIBUCIONES DEL ORIENTE S.A.S* - Operador de Montacargas',3,'',11,1),(25,'2025-12-19 13:44:16.839257','26','*GEODATOS Y CARTOGRAFÍA URBANA S.A.S* - Georreferenciación',3,'',11,1),(26,'2025-12-19 13:44:16.839293','25','*INGEOBRAS DEL MAGDALENA S.A.S* - operador de excavadora',3,'',11,1),(27,'2025-12-19 13:44:16.839329','24','*LOGÍSTICA INTEGRAL DEL OCCIDENTE S.A.S* - Operador de Montacargas',3,'',11,1),(28,'2025-12-19 13:44:16.839367','23','DATATECH SOLUTIONS S.A.S - Análisis Exploratorio de Datos en Python',3,'',11,1),(29,'2025-12-19 13:44:16.839400','22','INGENIERÍA Y CONSTRUCCIONES DEL CARIBE S.A.S - Operador de Minicargador',3,'',11,1),(30,'2025-12-19 13:44:16.839428','21','*OBRAS Y TERRAMOVIMIENTOS DEL NORTE S.A.S* - Operador de Retrocargador',3,'',11,1),(31,'2025-12-19 13:44:16.839457','20','*MAQUICONSTRUCCIONES DEL CENTRO S.A.S* - Operador de Retrocargador',3,'',11,1),(32,'2025-12-19 13:44:16.839485','19','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Tecnólogo en Procesos de la Industria Química',3,'',11,1),(33,'2025-12-19 13:44:16.839517','18','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Georreferenciación',3,'',11,1),(34,'2025-12-19 13:44:16.839552','17','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Explotación de obras civiles y mineras de acuerdo  con el manual  del  equipo',3,'',11,1),(35,'2025-12-19 13:44:16.839586','16','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Ciberseguridad',3,'',11,1),(36,'2025-12-19 13:44:16.839613','15','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Ciberseguridad',3,'',11,1),(37,'2025-12-19 13:44:16.839643','14','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Ciberseguridad',3,'',11,1),(38,'2025-12-19 13:44:16.839678','13','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Ciberseguridad',3,'',11,1),(39,'2025-12-19 13:44:16.839714','12','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Ciberseguridad',3,'',11,1),(40,'2025-12-19 13:44:16.839744','11','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Operador de Minicargador',3,'',11,1),(41,'2025-12-19 13:44:16.839777','10','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S - Operador de Montacargas',3,'',11,1),(42,'2025-12-19 13:44:16.839811','9','QUIMIPROCESOS S.A.S - Ciberseguridad',3,'',11,1),(43,'2025-12-19 13:44:16.839841','8','QUIMIPROCESOS S.A.S - Ciberseguridad',3,'',11,1),(44,'2025-12-19 13:44:16.839872','7','QUIMIPROCESOS S.A.S - Ciberseguridad',3,'',11,1),(45,'2025-12-19 13:44:16.839907','6','QUIMIPROCESOS S.A.S - Ciberseguridad',3,'',11,1),(46,'2025-12-19 13:44:16.839944','5','TOPOGRAFÍA Y GEODATOS S.A.S - Ciberseguridad',3,'',11,1),(47,'2025-12-19 13:44:16.839979','4','TECNOLOGÍAS INNOVATEC S.A.S - Ciberseguridad',3,'',11,1),(48,'2025-12-19 13:44:16.840013','3','construcción de obras civiles - operador de excavadora',3,'',11,1),(49,'2025-12-19 13:44:16.840047','2','construcción de obras civiles - operador de excavadora',3,'',11,1),(50,'2025-12-19 13:44:16.840082','1','ALTARA INGENIERIA SAS - operador de excavadora',3,'',11,1),(51,'2025-12-19 13:45:54.630680','23','Empresa maez',3,'',10,1),(52,'2025-12-19 13:45:54.630754','21','Empresa aperez',3,'',10,1),(53,'2025-12-19 13:45:54.630799','17','Empresa sin nombre',3,'',10,1),(54,'2025-12-19 13:45:54.630838','16','*CONSTRUTIERRAS DEL SUR S.A.S*',3,'',10,1),(55,'2025-12-19 13:45:54.630874','15','*ALMACENES Y DISTRIBUCIONES DEL ORIENTE S.A.S*',3,'',10,1),(56,'2025-12-19 13:45:54.630908','14','*GEODATOS Y CARTOGRAFÍA URBANA S.A.S*',3,'',10,1),(57,'2025-12-19 13:45:54.630942','13','*INGEOBRAS DEL MAGDALENA S.A.S*',3,'',10,1),(58,'2025-12-19 13:45:54.630976','12','*LOGÍSTICA INTEGRAL DEL OCCIDENTE S.A.S*',3,'',10,1),(59,'2025-12-19 13:45:54.631009','11','DATATECH SOLUTIONS S.A.S',3,'',10,1),(60,'2025-12-19 13:45:54.631043','10','INGENIERÍA Y CONSTRUCCIONES DEL CARIBE S.A.S',3,'',10,1),(61,'2025-12-19 13:45:54.631076','9','*OBRAS Y TERRAMOVIMIENTOS DEL NORTE S.A.S*',3,'',10,1),(62,'2025-12-19 13:45:54.631110','8','*MAQUICONSTRUCCIONES DEL CENTRO S.A.S*',3,'',10,1),(63,'2025-12-19 13:45:54.631143','7','INDUSTRIAS METALMECÁNICAS ANDINA S.A.S',3,'',10,1),(64,'2025-12-22 18:10:41.962068','7','Miguel Diaz',3,'',9,1),(65,'2025-12-22 18:10:41.962154','6','Carlos Mateus Gonzales gomez ',3,'',9,1),(66,'2025-12-22 18:10:41.962198','5','Martha Elena Mayorga',3,'',9,1),(67,'2025-12-22 18:12:17.286139','6','Administración',3,'',7,1),(68,'2025-12-22 18:12:17.286229','7','Agricola',3,'',7,1),(69,'2025-12-22 18:12:17.286276','9','Amasijos',3,'',7,1),(70,'2025-12-22 18:12:17.286315','10','Contrucciones',3,'',7,1),(71,'2025-12-22 18:12:17.286350','8','Ganadera',3,'',7,1),(72,'2025-12-22 18:12:17.286387','5','Salud',3,'',7,1),(73,'2025-12-22 18:12:43.972016','32','mnmnjkmnhgbv',3,'',10,1),(74,'2025-12-22 18:12:43.972100','18','Empresa sin nombre',3,'',10,1),(75,'2025-12-22 18:12:43.972146','3','construcción de obras civiles',3,'',10,1),(76,'2025-12-22 18:15:43.898727','15',' Desarrollo de Software - Análisis de datos',3,'',8,1),(77,'2025-12-22 18:15:43.898813','10',' Desarrollo de Software - Análisis Exploratorio de Datos en Python',3,'',8,1),(78,'2025-12-22 18:15:43.898858','2',' Desarrollo de Software - Ciberseguridad',3,'',8,1),(79,'2025-12-22 18:15:43.898896','4','Química Aplicada - Tecnólogo en Procesos de la Industria Química',3,'',8,1),(80,'2025-12-22 18:23:54.075002','2','Marcos Ferney Suarez Martinez',3,'',9,1),(81,'2025-12-22 19:19:34.699728','2',' Desarrollo de Software',3,'',7,1),(82,'2025-12-22 19:19:34.699814','4','Química Aplicada',3,'',7,1),(83,'2025-12-23 13:02:22.469928','39','MOVIMIENTOS Y CONSTRUCCIONES ANDINAS S.A.S',3,'',10,1),(84,'2025-12-23 13:02:22.470006','38','SERVICIOS LOGÍSTICOS Y TRANSPORTE INDUSTRIAL S.A.S',3,'',10,1),(85,'2025-12-23 13:02:22.470049','37','LOGÍSTICA Y SERVICIOS INDUSTRIALES DEL CARIBE S.A.S',3,'',10,1),(86,'2025-12-23 13:02:22.470086','36','LOGÍSTICA INDUSTRIAL ANDINA S.A.S',3,'',10,1),(87,'2025-12-23 13:02:22.470119','35','CONSTRUCCIONES Y MOVIMIENTOS DEL NORTE S.A.S',3,'',10,1),(88,'2025-12-23 13:02:22.470154','34','MAQUINARIAS DEL PACÍFICO S.A.S',3,'',10,1),(89,'2025-12-23 13:02:22.470188','33','GEODATA SOLUTIONS S.A.S',3,'',10,1),(90,'2025-12-23 13:02:22.470220','31','Contrucciones el Condor S.A',3,'',10,1),(91,'2025-12-23 13:02:22.470250','30','Contruboy S.A.S',3,'',10,1),(92,'2025-12-23 13:02:22.470282','29','Topógrafos unidos S.A.S',3,'',10,1),(93,'2025-12-23 13:02:22.470312','28','Minería S.A.S',3,'',10,1),(94,'2025-12-23 13:02:22.470344','27','LOGISTIWARE COLOMBIA S.A.S',3,'',10,1),(95,'2025-12-23 13:02:22.470375','26','SERVIMAQ INDUSTRIAL S.A.S',3,'',10,1),(96,'2025-12-23 13:02:22.470406','25','CONSTRUOBRAS & EQUIPOS S.A.S',3,'',10,1),(97,'2025-12-23 13:02:22.470436','24','MEDIO ORIENTE S.A.S',3,'',10,1),(98,'2025-12-23 13:02:22.470467','22','CONSTRUCCIONES ORIENTE S.A.S',3,'',10,1),(99,'2025-12-23 13:02:22.470499','20','CONSTRUCCIONES EFICACES S.A.S',3,'',10,1),(100,'2025-12-23 13:02:22.470531','19','* MAQUINARIAS DEL PACÍFICO S.A.S',3,'',10,1),(101,'2025-12-23 13:02:22.470563','6','QUIMIPROCESOS S.A.S',3,'',10,1),(102,'2025-12-23 13:02:22.470593','5','TOPOGRAFÍA Y GEODATOS S.A.S',3,'',10,1),(103,'2025-12-23 13:02:22.470623','4','TECNOLOGÍAS INNOVATEC S.A.S',3,'',10,1),(104,'2025-12-23 13:02:22.470653','2','Constructora FYT S.A.S',3,'',10,1),(105,'2025-12-23 13:02:22.470684','1','ALTARA INGENIERIA SAS',3,'',10,1),(106,'2025-12-23 13:53:49.129351','42','SERVICIOS DE MAQUINARIA DEL ALTIPLANO S.A.S (20251223-135238) - NIT: 901982345',3,'',10,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(7,'area_formacion','area'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(10,'empresas','empresa'),(9,'instructores','instructor'),(8,'programas','programa'),(6,'sessions','session'),(12,'solicitudes','documentosolicitud'),(11,'solicitudes','solicitud');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2025-12-19 14:14:45.574366'),(2,'auth','0001_initial','2025-12-19 14:14:46.468931'),(3,'admin','0001_initial','2025-12-19 14:14:46.704886'),(4,'admin','0002_logentry_remove_auto_add','2025-12-19 14:14:46.718415'),(5,'admin','0003_logentry_add_action_flag_choices','2025-12-19 14:14:46.736211'),(6,'area_formacion','0001_initial','2025-12-19 14:14:46.789097'),(7,'contenttypes','0002_remove_content_type_name','2025-12-19 14:14:46.974746'),(8,'auth','0002_alter_permission_name_max_length','2025-12-19 14:14:47.085854'),(9,'auth','0003_alter_user_email_max_length','2025-12-19 14:14:47.146137'),(10,'auth','0004_alter_user_username_opts','2025-12-19 14:14:47.163660'),(11,'auth','0005_alter_user_last_login_null','2025-12-19 14:14:47.267030'),(12,'auth','0006_require_contenttypes_0002','2025-12-19 14:14:47.271184'),(13,'auth','0007_alter_validators_add_error_messages','2025-12-19 14:14:47.288778'),(14,'auth','0008_alter_user_username_max_length','2025-12-19 14:14:47.406630'),(15,'auth','0009_alter_user_last_name_max_length','2025-12-19 14:14:47.532771'),(16,'auth','0010_alter_group_name_max_length','2025-12-19 14:14:47.573296'),(17,'auth','0011_update_proxy_permissions','2025-12-19 14:14:47.597149'),(18,'auth','0012_alter_user_first_name_max_length','2025-12-19 14:14:47.710663'),(19,'empresas','0001_initial','2025-12-19 14:14:47.754531'),(20,'empresas','0002_empresa_direccion','2025-12-19 14:14:47.843435'),(21,'empresas','0003_empresa_activo','2025-12-19 14:14:47.935232'),(22,'empresas','0004_empresa_nit','2025-12-19 14:14:48.006698'),(23,'programas','0001_initial','2025-12-19 14:14:48.154757'),(24,'instructores','0001_initial','2025-12-19 14:14:48.405636'),(25,'programas','0002_programa_codigo','2025-12-19 14:14:48.510892'),(26,'sessions','0001_initial','2025-12-19 14:14:48.576076'),(27,'solicitudes','0001_initial','2025-12-19 14:14:48.892647'),(28,'solicitudes','0002_solicitud_fecha_finalizacion_and_more','2025-12-19 14:14:49.050624'),(29,'empresas','0005_alter_empresa_nit','2025-12-23 13:17:19.951793'),(30,'solicitudes','0003_solicitud_correo_remitente','2025-12-24 16:15:21.524416'),(31,'solicitudes','0004_solicitud_documento_pdf','2026-01-06 14:19:10.302759'),(32,'solicitudes','0005_documentosolicitud','2026-01-15 14:42:37.304285');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('13ffq7t2gyn3afdq1wesgrv079vwlzqs','.eJxVjEEOwiAQRe_C2hAoUIpL956BzDCDVA0kpV0Z765NutDtf-_9l4iwrSVunZc4kzgLLU6_G0J6cN0B3aHemkytrsuMclfkQbu8NuLn5XD_Dgr08q0zOAwQTM4pgQNi7zENLo1qYoWWOJCzmtCzydp47ycE4Iw4Kh0Ga8T7AybbOSE:1vHNto:dsCXMWAftW9tWhNQV4wF-KbAhVpiaDfKpSCeSEyco5Q','2025-11-21 14:57:12.395575'),('22rpv7xyylv067tmqfr9zghummdbg7jx','.eJxVjEEOwiAQRe_C2hAoUIpL956BzDCDVA0kpV0Z765NutDtf-_9l4iwrSVunZc4kzgLLU6_G0J6cN0B3aHemkytrsuMclfkQbu8NuLn5XD_Dgr08q0zOAwQTM4pgQNi7zENLo1qYoWWOJCzmtCzydp47ycE4Iw4Kh0Ga8T7AybbOSE:1vloFp:GJhON2Zw3PDnY6LadApDQUtGj3mAAxUtbGJg7QIPt0o','2026-02-13 13:09:41.282679'),('a0qvdyv4j140d5ave4y1t5qn10cuzje2','.eJxVjDsOwjAQBe_iGln-xXEo6TmDtd5d4wCypTipEHeHSCmgfTPzXiLCtpa4dV7iTOIsnDj9bgnwwXUHdId6axJbXZc5yV2RB-3y2oifl8P9OyjQy7fWBBT0OA0h2GwdZXbB-Am11QwBBsNkbGYERynwmLRXhNmg8j7rBEq8P-9yOI4:1vaDbC:2dYPZzd-DAsemk2MKqNPzvwOVKxuuxubCT68xro1c40','2026-01-12 13:47:50.849468'),('aa4xuavrey3nbzwyfw44s6w377we0onn','.eJxVjEEOwiAQRe_C2hAoUIpL956BzDCDVA0kpV0Z765NutDtf-_9l4iwrSVunZc4kzgLLU6_G0J6cN0B3aHemkytrsuMclfkQbu8NuLn5XD_Dgr08q0zOAwQTM4pgQNi7zENLo1qYoWWOJCzmtCzydp47ycE4Iw4Kh0Ga8T7AybbOSE:1vXm9Y:XefbuLwF3K0_CjvDOGhjdAAwYnRE3SxTjwIaQlRtdps','2026-01-05 20:05:12.194431'),('h2m8lzi8cgqb5yeg0hpynpul3m3utm9c','.eJxVjEEOwiAQRe_C2hAoUIpL956BzDCDVA0kpV0Z765NutDtf-_9l4iwrSVunZc4kzgLLU6_G0J6cN0B3aHemkytrsuMclfkQbu8NuLn5XD_Dgr08q0zOAwQTM4pgQNi7zENLo1qYoWWOJCzmtCzydp47ycE4Iw4Kh0Ga8T7AybbOSE:1vQphE:yRu7RQvr6YasZck1jUYhVJgCNWCiNWLayA3rAQnQkI4','2025-12-17 16:27:16.737161'),('onk70coa16qoarlyhcbuhqlt3jifwk0y','.eJxVjEEOwiAQRe_C2hAoUIpL956BzDCDVA0kpV0Z765NutDtf-_9l4iwrSVunZc4kzgLLU6_G0J6cN0B3aHemkytrsuMclfkQbu8NuLn5XD_Dgr08q0zOAwQTM4pgQNi7zENLo1qYoWWOJCzmtCzydp47ycE4Iw4Kh0Ga8T7AybbOSE:1vSzEO:7nT-7NNfnZBj5faQed0LjsVjhavS2EQPBXJN5LIDK8E','2025-12-23 15:02:24.765287'),('onsz7oeuukh5kzuywrl0apywmd1ubyv3','.eJxVjEEOwiAQRe_C2hAoUIpL956BzDCDVA0kpV0Z765NutDtf-_9l4iwrSVunZc4kzgLLU6_G0J6cN0B3aHemkytrsuMclfkQbu8NuLn5XD_Dgr08q0zOAwQTM4pgQNi7zENLo1qYoWWOJCzmtCzydp47ycE4Iw4Kh0Ga8T7AybbOSE:1vCGXL:FMeQQyoTX6EUlORzsShMmtM7Gkmm9c4stCTsVuGjkE4','2025-11-07 12:04:51.328488'),('r97rw8fdj9jfi14ym2y4l1h9ev9yn7is','.eJxVjk0OgjAYRO_StZJCKaUu3XuG5vuroIYaClFjvLs1ccN25s3LvFW4Q86PNHOYJcsSlnSVSR0UG_N8pX2sDWnrJLbUg_TO9WTEg-4AGivaqJ0KsC5DWLPMYeSyrLcZAhXjr-ALTOdUUZqWecTqh1T_NlenxHI7_tmNYIA8lHUEix68iZEILLA4h9RY6nQvGlsWz7atGZ2YctqVpwggEbHTtW9aoz5fRh5OLQ:1vl5zK:U8OtJsBUey_w1GKGIJYqgDSzXytQX3kpntKpm8eS9nc','2026-02-11 13:53:42.555908');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresas_empresa`
--

DROP TABLE IF EXISTS `empresas_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empresas_empresa` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contacto` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correo` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_trabajadores` int NOT NULL,
  `municipio` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_registro` datetime(6) NOT NULL,
  `direccion` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `nit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `empresas_empresa_nit_d610c76d_uniq` (`nit`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresas_empresa`
--

LOCK TABLES `empresas_empresa` WRITE;
/*!40000 ALTER TABLE `empresas_empresa` DISABLE KEYS */;
INSERT INTO `empresas_empresa` VALUES (40,'MOVIMIENTOS Y CONSTRUCCIONES ANDINAS S.A.S','Liced Dayana Diaz Mayorga','3206157834','direccion@movandinas.com',41,'Duitama','2025-12-23 13:41:35.730335','Carrera 20 # 14-32',1,'901874639'),(41,'SERVICIOS DE MAQUINARIA DEL ALTIPLANO S.A.S','Jorge Iván Rojas Cely','3115829046','operaciones@maqaltiplano.com',27,'Sogamoso','2025-12-23 13:47:54.046959','Avenida El Sol # 9-71',1,'9004389176'),(43,'EXCAVACIONES Y PROYECTOS LA MONTAÑA S.A.S','Mauricio Alejandro Torres Pinzón','3172684519','supervision@laproyectosmontana.com',34,'Paipa','2025-12-23 17:42:26.696842','Kilómetro 3 Vía Pantano de Vargas',1,'9016549824'),(44,'SOLUCIONES INDUSTRIALES DEL CENTRO S.A.S','Natalia Fernanda López Ramírez','3149056728','mantenimiento@solindcentro.com',22,'Chiquinquirá','2025-12-23 18:55:53.457946','Carrera 9 # 17-64',1,'9007124589'),(46,'TERRAPLENES Y OBRAS PESADAS DEL ALTIPLANO S.A.S','Andrés Felipe Rojas Beltrán','3204869137','operaciones@terraplenesaltiplano.com',41,'Duitama','2025-12-23 19:42:11.460919','Carrera 18 # 42-19',1,'9019783456'),(47,'LOGÍSTICA Y ALMACENAMIENTO INDUSTRIAL SAN MIGUEL S.A.S','Diana Marcela Díaz Rodríguez','3126987451','dayadiz.23@gmail.com',17,'Sogamoso','2025-12-24 15:57:25.747400','Zona Industrial Calle 12 # 5-83',1,'9008457322'),(48,'OBRAS CIVILES Y SERVICIOS TECNOLÓGICOS DEL ORIENTE S.A.S','Julián Esteban Morales Castro','3168452097','contacto@ocst-oriente.com',14,'Moniquirá','2025-12-24 16:29:46.881392','Carrera 6 # 14-27',1,'9012769845'),(49,'INFRAESTRUCTURA Y MAQUINARIA DEL CARIBE INTERIOR S.A.S','Carlos Andrés Pineda Salazar','3195628743','coordinacion@imcaribeinterior.com',26,'El Banco','2025-12-24 16:41:20.555026','Calle 12 # 8-41 Barrio Centro',1,'9017394628'),(50,'DISTRIBUCIONES Y SERVICIOS LOGÍSTICOS LA SABANA S.A.S','Paola Andrea Mejía Fonseca','3108745629','talentohumano@dissabana.com',38,'Tocancipá','2025-12-24 22:20:09.927869','Parque Industrial La Sabana, Bodega 14',1,'9016843579'),(51,'MANTENIMIENTO Y SOLUCIONES HIDRÁULICAS DEL CENTRO S.A.S','Ricardo Andrés Velasco Molina','3169034827','mantenimiento@mshcentro.com',24,'Girardot','2025-12-27 19:52:08.430604','Carrera 12 # 22-45 Zona Industrial',1,'9017562843'),(52,'TECNOEQUIPOS Y MAQUINARIA PESADA DEL LLANO S.A.S','Laura Katherine Rincón Duarte','3207415938','operaciones@tecnoequiposllano.com',31,'Villavicencio','2025-12-27 20:11:44.056657','Kilómetro 5 Vía Puerto López',1,'9018426170'),(53,'PROYECTOS VIALES Y MOVIMIENTO DE TIERRAS EL PROGRESO S.A.S','Hernán Darío Muñoz Calderón','3186549072','coordinacion@pvmtierrasprogreso.com',23,'Pitalito','2025-12-29 12:15:54.867948','Carrera 5 # 12-38 Barrio La Castellana',1,'9016942581'),(54,'CONSULTORES TOPOGRÁFICOS Y AMBIENTALES DEL SUR S.A.S','Camilo Andrés Paredes Ríos','3175896241','proyectos@ctasur.com',16,'Mocoa','2025-12-29 12:55:10.960951','Calle 8 # 6-45 Barrio El Jardín',1,'9017328640'),(55,'LOGÍSTICA Y DISTRIBUCIÓN INDUSTRIAL DEL CARIBE S.A.S','Julián Esteban Cárdenas Mejía','3157724089','supervision@logiccaribe.com',29,'Soledad','2025-12-29 14:02:21.132096','Calle 30 # 18-62 Parque Industrial Las Américas',1,'9018645937'),(56,'ConstruPalermo S.A.S','Sofia Rodriguez','3236574321','dayadiz.23@gmail.com',56,'Palmira','2026-01-08 13:31:36.414156','calle 6 #67-65',1,'8600038318'),(57,'MOVIMIENTO DE TIERRAS Y OBRAS CIVILES SAN MIGUEL S.A.S','Andrés Felipe Correa Londoño','3126894510','operaciones@mtosanmiguel.com',21,'La Dorada','2026-01-14 21:19:28.297740','Carrera 9 # 34-21 Zona Industrial',1,'9019037462'),(58,'COMERCIALIZADORA Y ALMACENAMIENTO INDUSTRIAL ANDINA S.A.S','Natalia Sofía Hernández Quiroga','3114589063','administracion@caandina.com',18,'Duitama','2026-01-19 16:53:59.575002','Calle 18 # 42-19 Zona Industrial',1,'9019276844'),(59,'CONSTRUCCIONES Y SERVICIOS INTEGRALES DEL PACÍFICO S.A.S','Wilson Eduardo Mina Caicedo','3146975284','supervision@csipacifico.com',27,'Buenaventura','2026-01-22 20:00:59.312243','Calle 5 # 42-18 Barrio Industrial',1,'9019483726'),(61,'OBRAS Y SOLUCIONES DE INGENIERÍA DEL NORTE S.A.S','Diana Marcela Torres Buitrago','3178046921','operaciones@osingenierianorte.com',19,'Pamplona','2026-01-30 13:14:33.863318','Calle 7 # 5-36 Barrio Centro',1,'9019624853'),(62,'TRANSPORTES Y MOVIMIENTO DE TIERRAS LA SABANA S.A.S','Jorge Andrés Cárdenas López','3207458836','operaciones@tmlasabana.com',24,'Facatativá','2026-01-30 13:19:45.161341','Km 3 Vía Facatativá – Madrid',1,'9019857421'),(63,'INGENIERÍA Y MANTENIMIENTO DE MAQUINARIA PESADA DEL CARIBE S.A.S','Carlos Alberto Mejía Ríos','3186924571','mantenimiento@immpcaribe.com',21,'Cartagena','2026-01-30 13:37:45.217006','Zona Industrial Mamonal, Bodega 14',1,'9019748569');
/*!40000 ALTER TABLE `empresas_empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructores_instructor`
--

DROP TABLE IF EXISTS `instructores_instructor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructores_instructor` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correo` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructores_instructor`
--

LOCK TABLES `instructores_instructor` WRITE;
/*!40000 ALTER TABLE `instructores_instructor` DISABLE KEYS */;
INSERT INTO `instructores_instructor` VALUES (1,'Norberto Romero  Gutiérrez Perez','3142460488','norberto@sena.edu.com',1),(16,'Ederson infante','3147432569','Ederinfa@sena.edu.co',1),(17,'Juan Pérez','3229843125','juanpe@sena.edu.co',1);
/*!40000 ALTER TABLE `instructores_instructor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructores_instructor_especialidad`
--

DROP TABLE IF EXISTS `instructores_instructor_especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructores_instructor_especialidad` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `instructor_id` bigint NOT NULL,
  `programa_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `instructores_instructor__instructor_id_programa_i_80dc0c9e_uniq` (`instructor_id`,`programa_id`),
  KEY `instructores_instruc_programa_id_b9b8492b_fk_programas` (`programa_id`),
  CONSTRAINT `instructores_instruc_instructor_id_ba03593f_fk_instructo` FOREIGN KEY (`instructor_id`) REFERENCES `instructores_instructor` (`id`),
  CONSTRAINT `instructores_instruc_programa_id_b9b8492b_fk_programas` FOREIGN KEY (`programa_id`) REFERENCES `programas_programa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructores_instructor_especialidad`
--

LOCK TABLES `instructores_instructor_especialidad` WRITE;
/*!40000 ALTER TABLE `instructores_instructor_especialidad` DISABLE KEYS */;
INSERT INTO `instructores_instructor_especialidad` VALUES (1,1,1),(2,1,8),(29,16,5),(28,16,8),(31,17,5),(30,17,24);
/*!40000 ALTER TABLE `instructores_instructor_especialidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programas_programa`
--

DROP TABLE IF EXISTS `programas_programa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `programas_programa` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `duracion_horas` int DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `fecha_creacion` datetime(6) NOT NULL,
  `area_id` bigint NOT NULL,
  `codigo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `programas_programa_area_id_nombre_8bf86235_uniq` (`area_id`,`nombre`),
  CONSTRAINT `programas_programa_area_id_6d7cdeb9_fk_area_formacion_area_id` FOREIGN KEY (`area_id`) REFERENCES `area_formacion_area` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programas_programa`
--

LOCK TABLES `programas_programa` WRITE;
/*!40000 ALTER TABLE `programas_programa` DISABLE KEYS */;
INSERT INTO `programas_programa` VALUES (1,'operador de excavadora','Un operador de excavadora en el SENA es una persona que se forma para operar maquinaria pesada de manera segura y eficiente, realizando tareas como la excavación, carga, nivelación y transporte de materiales en proyectos de construcción, minería y obras civiles.',140,1,'2025-10-23 20:12:56.472977',1,''),(3,'Georreferenciación','La georreferenciación en la topografía del SENA es la técnica para asignar coordenadas geográficas (latitud, longitud, altura) a puntos, características o planos de un terreno, con el fin de ubicar elementos de forma precisa en la superficie terrestre.',48,1,'2025-11-12 13:11:45.564906',3,''),(5,'Operador de Retrocargador',' Un operador de retrocargador es un profesional capacitado para manejar maquinaria pesada como la retroexcavadora, realizando tareas de excavación, carga y nivelación de terrenos para construcción.',40,1,'2025-11-12 18:45:04.277187',1,''),(7,'Operador de Minicargador','Es un profesional que ha recibido formación técnica para manejar de forma segura y eficiente estos equipos compactos, que se utilizan para cargar, descargar, nivelar y desplazar materiales en diversas industrias como la construcción, la minería y la agricultura.',40,1,'2025-11-12 18:51:09.568284',1,''),(8,'Operador de Montacargas','Un operador de montacargas es una persona que ha recibido capacitación para manipular estos equipos de manera segura y eficiente en almacenes, fábricas y otros entornos logísticos. La formación cubre desde la operación básica hasta el mantenimiento preventivo y la normativa de seguridad, permitiendo el traslado de mercancías y la optimización de procesos. ',50,1,'2025-11-12 18:53:10.033247',1,'2345687'),(9,'Sistemas Hidráulicos en  Maquinaria Pesada','Los Sistemas Hidráulicos en Maquinaria Pesada se refieren a un programa de formación que enseña a los aprendices cómo funcionan, se operan y se mantienen los sistemas que usan fluidos a presión para realizar trabajos pesados. La formación se centra en los componentes clave como bombas, cilindros y válvulas, y su aplicación práctica en equipos como excavadoras, grúas y volquetes. ',40,1,'2025-11-12 18:55:55.581401',1,''),(16,'Interpretación de planos para maquinaria industrial ','El programa Interpretación de Planos para Maquinaria Industrial trata de enseñar a leer y entender los documentos técnicos gráficos (planos) que representan componentes y ensamblajes de maquinaria, desarrollando habilidades para comprender vistas, simbología, acotaciones y especificaciones técnicas, fundamental para el mantenimiento, fabricación y operación de máquinas en el sector industrial. ',40,0,'2025-12-22 19:02:37.274345',1,'6789564'),(17,'Operador de Bulldozer','forma técnicos para operar equipos como excavadoras y bulldozers en construcción, minería y agro, enseñando seguridad, inspección, mantenimiento básico, y manejo ambiental con simuladores modernos para prácticas seguras, preparando para labores en obra civil y otras industrias. ',40,1,'2025-12-23 19:41:21.235362',1,'4567876'),(24,'Operador Maquinaria Pesada (Tipo Volqueta)','El programa de Operador de Maquinaria Pesada del SENA forma integralmente para manejar equipos como retroexcavadoras, buldóceres y motoniveladoras, enfocándose en la seguridad, mantenimiento básico y operación eficiente, mediante formación teórico-práctica y simuladores avanzados, apuntando a desarrollar competencias para el sector construcción y minería, y culminando en una certificación de competencias laborales para operar la maquinaria según el fabricante y las necesidades del trabajo, incluyendo la identificación de componentes y fallas. ',40,1,'2026-01-19 20:59:30.786876',1,'4567321'),(25,'Minería Carbonera','Este programa hace parte del área de minas.',45,1,'2026-01-26 15:05:27.246127',12,'2134698');
/*!40000 ALTER TABLE `programas_programa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitudes_documentosolicitud`
--

DROP TABLE IF EXISTS `solicitudes_documentosolicitud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solicitudes_documentosolicitud` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `archivo` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_archivo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_subida` datetime(6) NOT NULL,
  `solicitud_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `solicitudes_document_solicitud_id_8e078eef_fk_solicitud` (`solicitud_id`),
  CONSTRAINT `solicitudes_document_solicitud_id_8e078eef_fk_solicitud` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitudes_solicitud` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitudes_documentosolicitud`
--

LOCK TABLES `solicitudes_documentosolicitud` WRITE;
/*!40000 ALTER TABLE `solicitudes_documentosolicitud` DISABLE KEYS */;
INSERT INTO `solicitudes_documentosolicitud` VALUES (6,'solicitudes/documentos/2026/01/solicitud_73_20260119_162854_1_solicitudes_20251222_19273_JFeh0AC.pdf','solicitudes_20251222_192736_uqdX1vT.pdf','2026-01-19 16:28:54.246869',73),(7,'solicitudes/documentos/2026/01/solicitud_73_20260119_162854_2_Document_2.pdf','Document 2.pdf','2026-01-19 16:28:54.375900',73),(8,'solicitudes/documentos/2026/01/solicitud_73_20260119_162854_3_reporte_consolidado_202512_eWa5CKo.pdf','reporte_consolidado_20251224_154805 (1).pdf','2026-01-19 16:28:54.395919',73),(9,'solicitudes/documentos/2026/01/solicitud_73_20260119_162854_4_reporte_consolidado_202512_fC1riQh.pdf','reporte_consolidado_20251229_140725.pdf','2026-01-19 16:28:54.417273',73),(10,'solicitudes/documentos/2026/01/solicitud_73_20260119_162854_5_solicitudes_20251222_192726.pdf','solicitudes_20251222_192726.pdf','2026-01-19 16:28:54.440262',73),(17,'solicitudes/documentos/2026/01/solicitud_81_20260130_133745_1_solicitudes_20251223_184742_1.pdf','solicitudes_20251223_184742 (1).pdf','2026-01-30 13:37:45.264745',81),(18,'solicitudes/documentos/2026/01/solicitud_81_20260130_133745_2_reporte_consolidado_202512_A543nZn.pdf','reporte_consolidado_20251222_191103.pdf','2026-01-30 13:37:45.319199',81),(19,'solicitudes/documentos/2026/01/solicitud_81_20260130_133745_3_empresas_20251212_134815.pdf','empresas_20251212_134815.pdf','2026-01-30 13:37:45.346909',81),(20,'solicitudes/documentos/2026/01/solicitud_81_20260130__FwJJucG.xlsx_-_Formato_Bitácora_Individual.pdf','GFPI-F-147 V5 - Bitácora4.xlsx - Formato Bitácora Individual.pdf','2026-01-30 13:37:45.372399',81),(21,'solicitudes/documentos/2026/01/solicitud_81_20260130_133745_5_solicitudes_20251222_192726.pdf','solicitudes_20251222_192726.pdf','2026-01-30 13:37:45.413178',81);
/*!40000 ALTER TABLE `solicitudes_documentosolicitud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitudes_solicitud`
--

DROP TABLE IF EXISTS `solicitudes_solicitud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solicitudes_solicitud` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha_recepcion` datetime(6) NOT NULL,
  `fecha_respuesta` datetime(6) DEFAULT NULL,
  `fecha_atencion` datetime(6) DEFAULT NULL,
  `estado` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observaciones` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `empresa_id` bigint NOT NULL,
  `instructor_asignado_id` bigint DEFAULT NULL,
  `programa_id` bigint NOT NULL,
  `fecha_finalizacion` datetime(6) DEFAULT NULL,
  `numero_aprendices` int DEFAULT NULL,
  `correo_remitente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documento_pdf` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `solicitudes_solicitud_empresa_id_8f63b86a_fk_empresas_empresa_id` (`empresa_id`),
  KEY `solicitudes_solicitu_instructor_asignado__67d25fd3_fk_instructo` (`instructor_asignado_id`),
  KEY `solicitudes_solicitu_programa_id_54afc508_fk_programas` (`programa_id`),
  CONSTRAINT `solicitudes_solicitu_instructor_asignado__67d25fd3_fk_instructo` FOREIGN KEY (`instructor_asignado_id`) REFERENCES `instructores_instructor` (`id`),
  CONSTRAINT `solicitudes_solicitu_programa_id_54afc508_fk_programas` FOREIGN KEY (`programa_id`) REFERENCES `programas_programa` (`id`),
  CONSTRAINT `solicitudes_solicitud_empresa_id_8f63b86a_fk_empresas_empresa_id` FOREIGN KEY (`empresa_id`) REFERENCES `empresas_empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitudes_solicitud`
--

LOCK TABLES `solicitudes_solicitud` WRITE;
/*!40000 ALTER TABLE `solicitudes_solicitud` DISABLE KEYS */;
INSERT INTO `solicitudes_solicitud` VALUES (45,'2025-12-23 13:41:35.750915',NULL,NULL,'RECIBIDA','Creada automáticamente desde correo: Solicitud programa de formación Operador de Minica',40,NULL,7,NULL,NULL,NULL,NULL),(51,'2025-12-23 19:42:11.497425',NULL,'2025-12-24 15:45:37.745543','FINALIZADA','Creada automáticamente desde correo: Solicitud programa de formación Operador de Bulldo',46,NULL,17,'2026-01-22 19:43:05.648802',41,NULL,''),(53,'2025-12-24 16:29:46.911739','2025-12-24 16:34:31.434370','2025-12-24 22:16:34.070042','ATENDIDA','Creada automáticamente desde correo: Solicitud programa de formación Operador de Minica',48,NULL,7,NULL,14,'dayadiz.23@gmail.com',NULL),(54,'2025-12-24 16:41:20.586900','2025-12-24 16:41:42.538144',NULL,'RESPONDIDA','Creada automáticamente desde correo: Solicitud información programa de formación Operad',49,NULL,1,NULL,26,'dayadiz.23@gmail.com',NULL),(70,'2026-01-14 15:02:32.049799',NULL,NULL,'RECIBIDA','Ninguno',50,NULL,16,NULL,30,'dayadiz.23@gmail.com','solicitudes/documentos/2026/01/solicitudes_20251223_184742_1.pdf'),(71,'2026-01-14 21:19:28.384351',NULL,NULL,'RECIBIDA','no lo  se ',57,NULL,1,NULL,21,'dayadiz.23@gmail.com','solicitudes/documentos/2026/01/solicitud_71_20260114_211928_Document_2.pdf'),(73,'2026-01-19 16:28:54.059169',NULL,NULL,'RECIBIDA','Creada automáticamente desde correo: Solicitud programa de formación Operador de Excava',57,NULL,1,NULL,21,'dayadiz.23@gmail.com','solicitudes/documentos/2026/01/solicitud_73_20260119_162854_1_solicitudes_20251222_19273_vjzS8dC.pdf'),(74,'2026-01-19 16:53:59.609528','2026-01-28 13:49:35.941372','2026-01-28 13:50:00.400269','ATENDIDA','Creada automáticamente desde correo: Solicitud programa de formación Operador de Montac',58,1,8,NULL,18,'dayadiz.23@gmail.com',''),(79,'2026-01-30 13:14:33.903056',NULL,NULL,'RECIBIDA','Creada automáticamente desde correo: Solicitud programa de formación Operador de Retroc',61,NULL,5,NULL,19,'dayadiz.23@gmail.com',''),(80,'2026-01-30 13:19:45.202649',NULL,NULL,'RECIBIDA','Creada automáticamente desde correo: Solicitud programa de formación Operador de Maquin',62,NULL,24,NULL,24,'liceddiaz.08@gmail.com',''),(81,'2026-01-30 13:37:45.251140','2026-01-30 13:38:32.932580','2026-01-30 13:39:58.056047','FINALIZADA','Creada automáticamente desde correo: Solicitud programa de formación Sistemas Hidráulic',63,17,9,'2026-01-30 13:40:57.080928',21,'liceddiaz.08@gmail.com','solicitudes/documentos/2026/01/solicitud_81_20260130_133745_1_solicitudes_20251223_18474_RNRKFLF.pdf');
/*!40000 ALTER TABLE `solicitudes_solicitud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'solicitudes_formacion'
--

--
-- Dumping routines for database 'solicitudes_formacion'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-30  9:06:32
